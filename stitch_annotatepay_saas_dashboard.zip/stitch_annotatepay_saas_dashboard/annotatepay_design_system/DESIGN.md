---
name: AnnotatePay Design System
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d1c1d9'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#9a8ca2'
  outline-variant: '#4e4356'
  surface-tint: '#dfb7ff'
  primary: '#dfb7ff'
  on-primary: '#4b007e'
  primary-container: '#9d00ff'
  on-primary-container: '#f7e5ff'
  inverse-primary: '#8c00e5'
  secondary: '#d3fbff'
  on-secondary: '#00363a'
  secondary-container: '#00eefc'
  on-secondary-container: '#00686f'
  tertiary: '#2ae500'
  on-tertiary: '#053900'
  tertiary-container: '#137b00'
  on-tertiary-container: '#afff95'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#f1daff'
  primary-fixed-dim: '#dfb7ff'
  on-primary-fixed: '#2d004f'
  on-primary-fixed-variant: '#6b00b0'
  secondary-fixed: '#7df4ff'
  secondary-fixed-dim: '#00dbe9'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f54'
  tertiary-fixed: '#79ff5b'
  tertiary-fixed-dim: '#2ae500'
  on-tertiary-fixed: '#022100'
  on-tertiary-fixed-variant: '#095300'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  data-lg:
    fontFamily: Space Mono
    fontSize: 20px
    fontWeight: '700'
    lineHeight: '1.2'
  data-sm:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0.05em
  label-caps:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  container-max: 1440px
---

## Brand & Style
The design system embodies a "Hacker Moderno" aesthetic—a sophisticated intersection of minimalist functionalism and cyberpunk edge. Designed for data annotators, the UI prioritizes focus and high-performance data density while maintaining a futuristic, high-contrast atmosphere.

The core style is **Minimalist Cyberpunk**. It utilizes a deep dark mode (Anthracite) to reduce eye strain during long labeling sessions, punctuated by ultra-vibrant neon accents. Visuals are characterized by technical precision, utilizing thin 1px borders, subtle glow effects that mimic hardware LEDs, and glassmorphic overlays with extremely low opacity to maintain a sense of digital depth without clutter.

## Colors
This design system operates on a strictly dark palette. The foundation is **Anthracite (#0a0a0a)**, providing a matte, non-reflective base. 

- **Electric Purple (#9D00FF)** is the structural color, used for primary borders, branding elements, and active states.
- **Cyan Blue (#00F0FF)** serves as the high-action accent for buttons, interactive toggles, and primary CTAs.
- **Neon Green (#39FF14)** is reserved exclusively for "Success" states and "High Earnings" metrics, symbolizing growth.
- **Crimson Red (#FF003C)** signals critical errors, low balance, or data validation failures.

Surface colors should use varying shades of matte grey (e.g., `#121212`, `#1A1A1A`) to create hierarchy through tonal layering rather than shadows.

## Typography
The system uses a dual-font strategy. **Inter** provides high readability for UI navigation and descriptive text, ensuring the interface feels modern and professional. **Space Mono** is utilized for all technical data, earnings, timestamps, and terminal-style inputs to reinforce the "Hacker" aesthetic.

All labels and meta-data should be set in **Space Mono** with increased letter-spacing. Headings use **Inter** with tight tracking to create a bold, authoritative impact. Monospace elements should be used sparingly for narrative text but are mandatory for any numerical value or code-like attribute.

## Layout & Spacing
This design system employs a **12-column fluid grid** for desktop and a **4-column grid** for mobile. The spacing rhythm is strictly based on a **4px baseline**, ensuring all elements align with mathematical precision.

Layouts should favor high-density information displays. Data tables and annotation grids should use "Zebra" styling—alternating row backgrounds of `#0a0a0a` and `#121212` with 1px Electric Purple borders. Margins are kept tight to maximize screen real estate for data tasks, while primary containers use subtle padding to prevent visual crowding.

## Elevation & Depth
In this design system, depth is achieved through **Tonal Layers** and **Subtle Glows** rather than traditional shadows. 

1.  **Base Layer:** Anthracite (#0a0a0a).
2.  **Surface Layer:** Matte Black (#121212) with a 1px Electric Purple border at 20% opacity.
3.  **Floating/Glass Layer:** Semi-transparent panels with a `backdrop-filter: blur(12px)` and a background color of `rgba(255, 255, 255, 0.03)`.
4.  **Active Elevation:** Elements in focus or active state should emit a `0px 0px 8px` outer glow (box-shadow) using the element's primary accent color at 40% opacity.

Avoid all heavy, dark shadows; the darkness of the background makes them invisible. Instead, use thin borders to define edges.

## Shapes
The shape language is **Sharp (0px)**. To maintain the aggressive, technical feel of a terminal or high-end hacking tool, all corners are strictly 90 degrees. 

The only exception to the sharp-corner rule is the "Success" or "Verified" badge, which may use a 45-degree chamfer (clipped corner) to imply a more complex industrial design. Standard UI components like buttons, inputs, and cards must remain perfectly rectangular with crisp 1px strokes.

## Components

### Buttons
- **Primary:** Background: Cyan Blue (#00F0FF); Text: Black (#000000); Corners: Sharp. Hover state: Add a 10px outer glow of Cyan Blue.
- **Secondary:** Background: Transparent; Border: 1px Electric Purple; Text: Electric Purple. Hover: Fill background with Purple at 10% opacity.

### Input Fields
- **Terminal Style:** Background: #0a0a0a; Border-bottom: 1px Electric Purple. Use **Space Mono** for input text. Prefix with a cyan ">" character to mimic a command line.

### Cards
- Background: #121212; Border: 1px rgba(157, 0, 255, 0.2); Corner: Sharp. Header area should have a subtle horizontal zebra-stripe pattern.

### Progress Bars
- Track: #1A1A1A; Indicator: Cyan Blue (#00F0FF) with a 2px Neon Green "glow" tip.

### Data Tables
- Rows: Alternating #0a0a0a and #121212.
- Borders: 1px vertical separators in dark grey; no horizontal borders except for the header.
- Text: All numbers in Space Mono.

### Status Chips
- Small, rectangular labels. Success uses Neon Green text on a dark green background (10% opacity). Alerts use Crimson Red text on a dark red background (10% opacity).